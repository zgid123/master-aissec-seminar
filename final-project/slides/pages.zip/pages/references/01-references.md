---
layout: default
hideInToc: true
transition: slide-left
---

# Tài liệu tham khảo

<div class="grid grid-cols-2 gap-x-6 gap-y-1.5 mt-2 text-slate-700 [&_p]:!m-0 [&_p]:!text-[13px] [&_p]:!leading-snug [&_strong]:text-slate-900 [&_a]:text-sky-700">
  <div class="flex flex-col gap-2">
    <p>
      <strong>NIST (2025)</strong> <span class="venue">NIST SP</span><br />
      <a href="https://pages.nist.gov/800-63-4/sp800-63b/session/" target="_blank">SP 800-63B-4: Digital Identity Guidelines - Session Management</a>
    </p>
    <p>
      <strong>OWASP (2024)</strong> <span class="venue">Guideline</span><br />
      <a href="https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html" target="_blank">Session Management Cheat Sheet</a>
    </p>
    <p>
      <strong>Dhakal et al. (2018)</strong> <span class="venue">ACM CHI</span><br />
      <a href="https://doi.org/10.1145/3173574.3174220" target="_blank">Observations on typing from 136 million keystrokes</a>
    </p>
    <p>
      <strong>Killourhy &amp; Maxion (2009)</strong> <span class="venue">IEEE DSN</span><br />
      <a href="https://doi.org/10.1109/DSN.2009.5270346" target="_blank">Comparing anomaly-detection algorithms for keystroke dynamics</a>
    </p>
    <p>
      <strong>Bours (2012)</strong> <span class="venue">IST-Report</span><br />
      <span>Continuous keystroke dynamics: A different perspective towards biometric evaluation</span>
    </p>
    <p>
      <strong>Kiyani et al. (2020)</strong> <span class="venue">IEEE Access</span><br />
      <a href="https://doi.org/10.1109/ACCESS.2020.3019467" target="_blank">Continuous user authentication featuring keystroke dynamics based on RCM</a>
    </p>
    <p>
      <strong>NIST/SEMATECH</strong> <span class="venue">Handbook</span><br />
      <span>e-Handbook of Statistical Methods, Mục 6.3.2.3: CUSUM Control Charts</span>
    </p>
  </div>

  <div class="flex flex-col gap-2">
    <p>
      <strong>Liu, Ting, Zhou (2008)</strong> <span class="venue">IEEE ICDM</span><br />
      <a href="https://doi.org/10.1109/ICDM.2008.17" target="_blank">Isolation forest: Anomaly detection with isolation</a>
    </p>
    <p>
      <strong>Acien et al. (2021)</strong> <span class="venue">arXiv</span><br />
      <a href="https://doi.org/10.1109/TBIOM.2021.3112540" target="_blank">TypeNet: Deep Learning Keystroke Biometrics</a>
    </p>
    <p>
      <strong>Stragapede et al. (2024)</strong> <span class="venue">NCA</span><br />
      <a href="https://doi.org/10.1007/s00521-024-10140-2" target="_blank">TypeFormer: Transformers for mobile keystroke biometrics</a>
    </p>
    <p>
      <strong>Stragapede et al. (2025)</strong> <span class="venue">Pattern Recognition</span><br />
      <a href="https://doi.org/10.1016/j.patcog.2024.111287" target="_blank">KVC-onGoing: Keystroke Verification Challenge (&gt; 185.000 người)</a>
    </p>
    <p>
      <strong>TypingDNA (2024)</strong> <span class="venue">Industry</span><br />
      <span>ActiveLock: Continuous endpoint identity authentication</span>
    </p>
    <p>
      <strong>R Core Team</strong> <span class="venue">Documentation</span><br />
      <span><code>mad</code>: Median Absolute Deviation (hệ số hiệu chỉnh phân phối chuẩn 1,4826)</span>
    </p>
  </div>
</div>

<style scoped>
.venue { margin-left: 4px; padding: 1px 6px; border-radius: 999px; background: #e0f2fe; color: #0369a1; font-size: 11px; font-weight: 700; white-space: nowrap; }
</style>
