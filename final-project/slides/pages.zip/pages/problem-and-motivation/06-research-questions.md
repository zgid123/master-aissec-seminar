---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Câu hỏi nghiên cứu

<p class="text-[13px] text-slate-500 font-normal -mt-1.5 mb-2">Kết quả bước đầu, chưa kết luận</p>

<div class="-mt-2 rounded bg-slate-800 px-4 py-2 text-[15px] font-medium text-white text-center leading-snug">
  Phát hiện sớm <b>người lạ</b> đang dùng phiên, mà <b>không làm phiền</b> chủ thật?
</div>

<div class="mt-3 grid grid-cols-[1fr_1.35fr_1.2fr] gap-x-3.5 gap-y-2.5 items-center text-[14px] leading-snug">
  <div class="font-bold text-slate-500 text-[12px] uppercase tracking-wider">CÂU HỎI</div>
  <div class="font-bold text-slate-500 text-[12px] uppercase tracking-wider">GIẢ THUYẾT</div>
  <div class="font-bold text-slate-500 text-[12px] uppercase tracking-wider">KẾT QUẢ BƯỚC ĐẦU</div>

  <div v-click="1" class="contents">
    <div class="border-l-4 border-sky-500 bg-sky-50 px-3 py-2 rounded-r">
      <b>RQ1</b><br><span class="text-[13px] text-slate-600">Ngưỡng riêng từng người</span>
    </div>
    <div class="text-slate-700">Ngưỡng riêng giúp chủ thật ít bị hỏi MFA hơn.</div>
    <div class="rounded bg-amber-100/90 border border-amber-300 px-3 py-1.5 text-amber-900">
      <b class="text-[14px]">Chưa kết luận</b>
      <div class="text-[12px] text-amber-800">L1 và IF cho chiều ngược nhau.</div>
    </div>
  </div>

  <div v-click="2" class="contents">
    <div class="border-l-4 border-violet-500 bg-violet-50 px-3 py-2 rounded-r">
      <b>RQ2</b><br><span class="text-[13px] text-slate-600">Cộng dồn bằng chứng</span>
    </div>
    <div class="text-slate-700">Cộng dồn bắt kẻ lạ tốt hơn xét từng đoạn riêng.</div>
    <div class="rounded bg-amber-50 border border-amber-300 px-3 py-1.5 text-amber-900">
      <b class="text-[14px]">Gợi ý ban đầu</b>
      <div class="text-[12px] text-amber-800">Phát hiện tăng 0,36 &rarr; 0,63 (IF), nhưng chưa ghép cùng mức MFA.</div>
    </div>
  </div>

  <div v-click="3" class="contents">
    <div class="border-l-4 border-slate-400 bg-slate-50 px-3 py-2 rounded-r">
      <b>RQ3</b><br><span class="text-[13px] text-slate-600">Cập nhật sau MFA</span>
    </div>
    <div class="text-slate-700">Cập nhật hồ sơ sau MFA giảm từ chối nhầm.</div>
    <div class="rounded bg-slate-100 border border-slate-300 px-3 py-1.5 text-slate-700">
      <b class="text-[14px]">Chưa thực hiện</b>
      <div class="text-[12px] text-slate-500">P2 chưa triển khai.</div>
    </div>
  </div>
</div>

<!--
Mục tiêu: 0:30

Chúng em nêu ba câu hỏi, nhưng kết quả hiện mới ở mức gợi ý. Cộng dồn tăng tỷ lệ phát hiện, nhưng chưa so được ở cùng mức MFA. Câu hỏi thứ ba cần dữ liệu nhiều ngày.
-->
