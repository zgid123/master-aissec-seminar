---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Mô hình đe dọa

<div class="-mt-2 rounded bg-amber-50 border border-amber-300 px-3.5 py-1.5 text-[13.5px] text-amber-900 leading-snug">
  <b>Giả định kẻ tấn công:</b> Đã có phiên hợp lệ (ngồi vào máy mở hoặc có cookie); không sửa được hồ sơ máy chủ, không bẻ được TLS.
</div>

<div class="mt-2.5 grid grid-cols-[0.85fr_1.35fr] gap-4 items-start text-[14px] leading-snug">
  <div class="flex flex-col gap-2">
    <div class="text-[12px] font-bold uppercase tracking-wider text-slate-500">Tài sản cần bảo vệ</div>
    <div class="border-l-4 border-rose-500 bg-rose-50/80 px-3 py-1.5 rounded-r">
      <b>Phiên đã đăng nhập:</b> Không để kẻ lạ dùng quyền hạn của chủ.
    </div>
    <div class="border-l-4 border-amber-500 bg-amber-50/80 px-3 py-1.5 rounded-r">
      <b>Trải nghiệm chủ thật:</b> Không hỏi MFA quá nhiều, không thu hồi oan.
    </div>
    <div class="border-l-4 border-violet-500 bg-violet-50/80 px-3 py-1.5 rounded-r">
      <b>Hồ sơ nhịp gõ:</b> Tránh bị chèn dữ liệu xấu làm sai lệch nhận dạng.
    </div>
    <div class="border-l-4 border-emerald-500 bg-emerald-50/80 px-3 py-1.5 rounded-r">
      <b>Riêng tư người dùng:</b> Không lưu ký tự, chỉ ghi nhận thời điểm.
    </div>
  </div>

  <div>
    <div class="text-[12px] font-bold uppercase tracking-wider text-slate-500">Kịch bản tấn công</div>
    <div class="mt-1.5 grid grid-cols-[38px_1fr_80px] gap-x-2.5 gap-y-2 items-center text-[13.5px]">
      <div v-click="1" class="contents">
        <div class="rounded bg-rose-600 py-0.5 text-center font-black text-white text-[12px]">A1</div>
        <div class="text-slate-800">Người lạ dùng máy đang mở, gõ theo thói quen của mình.</div>
        <div class="rounded bg-emerald-100 px-2 py-0.5 text-center font-bold text-emerald-800 text-[12px]">Đã đo</div>
      </div>
      <div v-click="2" class="contents">
        <div class="rounded bg-rose-400 py-0.5 text-center font-black text-white text-[12px]">A2</div>
        <div class="text-slate-600">Biết nội dung cần gõ, nhưng không biết nhịp gõ của chủ.</div>
        <div class="rounded bg-slate-200 px-2 py-0.5 text-center font-bold text-slate-600 text-[12px]">Chưa đo</div>
      </div>
      <div v-click="2" class="contents">
        <div class="rounded bg-rose-300 py-0.5 text-center font-black text-white text-[12px]">A3</div>
        <div class="text-slate-600">Luyện bắt chước nhịp gõ của chủ thật.</div>
        <div class="rounded bg-slate-200 px-2 py-0.5 text-center font-bold text-slate-600 text-[12px]">Chưa đo</div>
      </div>
      <div v-click="2" class="contents">
        <div class="rounded bg-slate-500 py-0.5 text-center font-black text-white text-[12px]">A4</div>
        <div class="text-slate-600">Ghi lại gói dữ liệu nhịp gõ rồi gửi phát lại (replay).</div>
        <div class="rounded bg-slate-200 px-2 py-0.5 text-center font-bold text-slate-600 text-[12px]">Chưa đo</div>
      </div>
    </div>
  <div v-click="3" class="mt-3 rounded-lg bg-slate-800 px-3.5 py-2 text-[13px] text-white">
    <b>N</b> = phím đầu tiên của người lạ. <b>TTD (Time To Detection, thời gian đến lúc phát hiện)</b> luôn tính từ N.
  </div>
  </div>
</div>

<!--
Mục tiêu: 0:30

Kẻ tấn công đã có phiên hợp lệ; kịch bản chính là A1: người lạ ngồi vào máy đang mở và gõ theo thói quen. Hậu quả có hai chiều: kẻ lạ lọt thì phiên bị chiếm, còn chủ thật bị phiền hoặc bị thu hồi oan thì mất quyền truy cập. N là phím đầu của người lạ và TTD tính từ N.
-->
