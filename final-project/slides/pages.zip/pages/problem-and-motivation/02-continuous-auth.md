---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Xác thực liên tục

<p class="text-[13px] text-slate-500 font-normal -mt-1.5 mb-2">Định nghĩa và ứng dụng thực tế</p>

<div class="fig" style="height:270px">
  <img src="/img/H2_dinh_nghia_tu_du_lieu_den_quyet_dinh_trim.png" alt="Từ dữ liệu đến quyết định" />
</div>

<div class="chips c3 mt-3 text-[13.5px] leading-snug">
  <div class="rounded-lg border-l-4 border-sky-600 bg-sky-50/90 p-2.5 shadow-sm">
    <b>Đánh giá liên tục</b> tín hiệu trong phiên &rarr; tiếp tục / hỏi MFA / thu hồi
  </div>

  <div class="rounded-lg border-l-4 border-emerald-600 bg-emerald-50/90 p-2.5 shadow-sm">
    <b>Xác minh 1:1:</b> "đúng chủ không?", không phải "đây là ai"
  </div>

  <div v-click="1" class="rounded-lg border-l-4 border-amber-500 bg-amber-50/90 p-2.5 shadow-sm">
    <b>TypingDNA ActiveLock:</b> theo dõi cách gõ, khóa máy hoặc cảnh báo.<br>
  </div>
</div>

<!--
Mục tiêu: 1:00

Xác thực liên tục là kiểm tra thêm tín hiệu ngay trong phiên, thay vì chỉ lúc đăng nhập. Đây là xác minh một-một, không nhận dạng người dùng. Ngoài thực tế đã có sản phẩm như ActiveLock (hãng nêu: kiểm tra ngắn ~50 ký tự, sâu 150–200 ký tự, không so trực tiếp với TTD của nhóm), nhưng đó là mô tả của nhà cung cấp, và hệ thống đó còn dùng thêm tín hiệu khác nên không tương đương hệ thống của nhóm.
-->
