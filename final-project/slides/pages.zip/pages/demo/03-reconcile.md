---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Demo 3 · Đối chiếu kết quả

<DemoProgress :active="3" />

<div class="mt-2 grid grid-cols-[1.1fr_1.2fr] gap-4 text-[14px] leading-snug items-start">
  <!-- Left: Reconcile Output Block -->
  <div class="rounded-lg bg-slate-900 border border-slate-700 p-3 font-mono text-[12.5px] text-slate-200 shadow-md">
    <div class="text-[11px] text-slate-400 font-sans uppercase font-bold border-b border-slate-700 pb-1 mb-2">
      Kết quả đối chiếu độc lập (Reconciliation Log)
    </div>
    <div class="text-slate-400">// Kiểm tra 6 nhóm toàn vẹn dữ liệu:</div>
    <div class="text-emerald-400 mt-1 font-bold">"issue_counts": {</div>
    <div class="pl-4 text-emerald-300">
      "step": <span class="font-black text-white bg-emerald-700 px-1 rounded">0</span>, &nbsp;&nbsp;&nbsp;"events": <span class="font-black text-white bg-emerald-700 px-1 rounded">0</span>,<br>
      "outcome": <span class="font-black text-white bg-emerald-700 px-1 rounded">0</span>, "exposure": <span class="font-black text-white bg-emerald-700 px-1 rounded">0</span>,<br>
      "user": <span class="font-black text-white bg-emerald-700 px-1 rounded">0</span>, &nbsp;&nbsp;&nbsp;&nbsp;"macro": <span class="font-black text-white bg-emerald-700 px-1 rounded">0</span>
    </div>
    <div class="text-emerald-400 font-bold">}</div>
    <div class="mt-2 text-[11px] text-emerald-400 border-t border-slate-700 pt-1">
      &check; Tất cả 6/6 bài kiểm tra khớp 100%
    </div>
  </div>

  <!-- Right: Verification Details -->
  <div class="flex flex-col gap-2.5 text-[13.5px]">
    <div class="rounded border-l-4 border-sky-500 bg-sky-50 p-2.5 shadow-sm">
      <b class="text-sky-900 text-[14px]">Bộ đối chiếu độc lập:</b><br>
      <span class="text-slate-700">Được viết riêng bởi thành viên khác, chạy kiểm toán độc lập trên toàn bộ log sinh ra từ mô hình.</span>
    </div>

  <div v-click="1" class="rounded border-l-4 border-emerald-500 bg-emerald-50 p-2.5 shadow-sm">
    <b class="text-emerald-900 text-[14px]">Khớp hoàn toàn 0 sai lệch:</b><br>
    <span class="text-slate-700">
      <b>29.183</b> quyết định, <b>7.600</b> sự kiện MFA/thu hồi, và <b>3.520</b> kết cục đều khớp chính xác.
    </span>
  </div>

  <div v-click="2" class="rounded border-l-4 border-slate-500 bg-slate-50 p-2 shadow-sm text-slate-700">
    Chỉ số chẩn đoán mức cửa sổ (FAR, FRR, EER) khớp toàn bộ <b>8/8 cặp</b>.
  </div>
  </div>
</div>

<!--
Mục tiêu: 0:30

Để chắc các con số tính đúng, bộ đối chiếu do thành viên khác viết độc lập đã chấm lại log và khớp. Đây là kiểm tra tính nhất quán của phép tính, chưa nói gì về hiệu quả với người thật.
-->
