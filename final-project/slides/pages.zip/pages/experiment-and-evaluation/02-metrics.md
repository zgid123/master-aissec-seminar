---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Chỉ số đánh giá

<p class="text-[13px] text-slate-500 font-normal -mt-1.5 mb-2">Bắt người lạ, không làm phiền chủ thật</p>

<div class="mt-1.5 grid grid-cols-2 gap-3.5 text-[14px] leading-snug">
  <div class="rounded-lg border-t-4 border-rose-500 bg-white p-3 shadow-sm">
    <div class="flex items-center gap-1.5 font-bold text-rose-800 text-[15px]">
      <div class="i-carbon-user-filled text-lg"></div> Bắt người lạ (An ninh)
    </div>
    <ul class="mt-1.5 pl-4 list-disc space-y-1 text-slate-700">
      <li><b>Tỷ lệ phát hiện:</b> tỷ lệ kịch bản có cảnh báo sau N.</li>
      <li><b>Median TTD:</b> số phím từ N đến khi phát hiện.</li>
      <li><b>Trong 150 phím:</b> tỷ lệ phát hiện trong chân trời (L = 150).</li>
    </ul>
  </div>

  <div class="rounded-lg border-t-4 border-sky-500 bg-white p-3 shadow-sm">
    <div class="flex items-center gap-1.5 font-bold text-sky-800 text-[15px]">
      <div class="i-carbon-user-favorite text-lg"></div> Không làm phiền chủ thật (Khả dụng)
    </div>
    <ul class="mt-1.5 pl-4 list-disc space-y-1 text-slate-700">
      <li><b>MFA/giờ:</b> tần suất hỏi xác thực lại trên phiên chủ thật.</li>
      <li><b>Thu hồi oan:</b> số lần hệ thống đóng phiên nhầm của chủ.</li>
    </ul>
  </div>
</div>

<!-- Bẫy mẫu số -->
<div v-click="1" class="mt-2.5 rounded-lg border-2 border-violet-400 bg-violet-50/80 p-2.5 flex items-center justify-between text-[13.5px]">
  <div class="max-w-[55%]">
    <div class="font-bold text-violet-900 text-[14px]">Lưu ý về mẫu số</div>
    <div class="text-slate-700 mt-0.5">
      Đề tài luôn <b>báo cả hai cách tính</b> để đảm bảo tính khách quan và minh bạch.
    </div>
  </div>
  <div class="text-right bg-white/90 p-2 rounded border border-violet-200">
    <div class="text-[12px] text-slate-500">IF, P1:</div>
    <div class="text-[16px] font-black text-rose-700">
      <b>0,755</b> <span class="text-[12px] font-normal text-slate-500">(bỏ 72 ca)</span> &rarr; <b>0,613</b> <span class="text-[12px] font-bold text-slate-800">(đủ 432)</span>
    </div>
  </div>
</div>

<!-- Đạt khi -->
<div v-click="2" class="mt-2 rounded bg-slate-800 px-3 py-1.5 text-[12.5px] text-white flex items-center justify-between">
  <span class="font-bold text-amber-300">Ràng buộc đạt (đặt trước):</span>
  <span>Phát hiện &ge; 80%</span>
  <span>&bull;</span>
  <span>Median TTD &le; 150 phím</span>
  <span>&bull;</span>
  <span>Chưa cảnh báo tại 150 phím &le; 15%</span>
  <span>&bull;</span>
  <span>Không thu hồi oan (0 ca)</span>
</div>

<div class="mt-1 text-[11px] text-slate-400 italic text-right">
  * FAR (False Acceptance Rate), FRR (False Rejection Rate), EER (Equal Error Rate): chỉ số chẩn đoán ở mức cửa sổ.
</div>

<!--
Mục tiêu: 0:45

Chúng em đo hai chiều ngược nhau: bắt người lạ và không làm phiền chủ thật. Có một bẫy mẫu số: nếu loại các ca đã bị thu hồi trước khi người lạ gõ, cấu hình thu hồi oan nhiều lại có tỷ lệ phát hiện đẹp hơn, nên chúng em báo cả hai cách tính. Cấu hình chỉ đạt khi thỏa cả bốn ràng buộc, đặt trước khi chạy.
-->