---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Dữ liệu và quy trình

<div class="-mt-1.5 mb-2 flex items-center justify-between">
  <span class="text-[13px] text-slate-500 font-normal">Dữ liệu mô phỏng</span>
  <span class="rounded bg-rose-600 px-2 py-0.5 text-[11px] font-bold text-white tracking-wide">DỮ LIỆU MÔ PHỎNG</span>
</div>

<div class="mt-1 grid grid-cols-3 gap-3 text-center text-[15px]">
  <div class="rounded-lg bg-sky-50 border border-sky-200 px-3 py-2.5 shadow-sm">
    <div class="text-[34px] leading-none font-black text-sky-700">4</div>
    <div class="text-slate-700 font-medium mt-1">hồ sơ nhịp gõ</div>
  </div>
  <div class="rounded-lg bg-sky-50 border border-sky-200 px-3 py-2.5 shadow-sm">
    <div class="text-[34px] leading-none font-black text-sky-700">28.800</div>
    <div class="text-slate-700 font-medium mt-1">lần gõ (24 phiên)</div>
  </div>
  <div class="rounded-lg bg-sky-50 border border-sky-200 px-3 py-2.5 shadow-sm">
    <div class="text-[34px] leading-none font-black text-sky-700">432</div>
    <div class="text-slate-700 font-medium mt-1">kịch bản / cấu hình</div>
  </div>
</div>

<div class="mt-3 grid grid-cols-[1.1fr_1.3fr] gap-4 text-[13.5px] leading-snug">
  <div v-click="1">
    <div class="font-bold text-slate-700 mb-1 text-[13px] uppercase tracking-wider">Chia dữ liệu theo ngày</div>
    <div class="grid grid-cols-3 gap-1.5 text-center">
      <div class="rounded border-2 border-emerald-500 bg-emerald-50 py-2.5">
        <b class="text-emerald-900">Ngày 1</b><br>
        <span class="text-[12px] text-emerald-700">Huấn luyện (Train)</span>
      </div>
      <div class="rounded border-2 border-amber-500 bg-amber-50 py-2.5">
        <b class="text-amber-900">Ngày 2</b><br>
        <span class="text-[11.5px] text-amber-800 leading-tight block mt-0.5">Validation (chỉnh điểm &amp; ngưỡng)</span>
      </div>
      <div class="rounded border-2 border-rose-500 bg-rose-50 py-2.5">
        <b class="text-rose-900">Ngày 3</b><br>
        <span class="text-[12px] text-rose-700">Kiểm thử (Test khóa)</span>
      </div>
    </div>
  </div>
  <div v-click="2" class="flex flex-col justify-center">
    <div class="fig" style="height:150px; width:100%">
      <img src="/img/takeover_bar.svg" alt="Kịch bản tiếp quản A1: 525 phím" class="w-full h-full object-contain" />
    </div>
    <div class="mt-2 text-[12px] text-slate-600 italic text-center">
      * Mô hình không biết N; N chỉ dùng để chấm kết quả.
    </div>
  </div>
</div>

<!--
Mục tiêu: 0:35

Dữ liệu là bốn hồ sơ mô phỏng nên kết quả chỉ dùng kiểm tra quy trình. Chúng em chia theo phiên và theo ngày để tránh rò rỉ. Mỗi kịch bản nối 225 phím của chủ thật với 300 phím của người lạ và đo thời gian phát hiện từ điểm đổi người.
-->