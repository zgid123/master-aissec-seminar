---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Giới hạn nghiên cứu

<div class="mt-2 grid grid-cols-2 gap-3 text-[13.5px] leading-snug">
  <div class="rounded-lg border-l-4 border-rose-500 bg-rose-50/80 p-2.5 shadow-sm">
    <div class="font-bold text-rose-900 text-[14.5px]">Dữ liệu mô phỏng</div>
    <div class="mt-1 text-slate-700">Cho thấy quy trình phân tích chạy đúng và chặt chẽ, nhưng chưa phản ánh đầy đủ độ biến động trên người dùng thật.</div>
  </div>

  <div v-click="1" class="rounded-lg border-l-4 border-rose-500 bg-rose-50/80 p-2.5 shadow-sm">
    <div class="font-bold text-rose-900 text-[14.5px]">Mới đo một kiểu tấn công (A1)</div>
    <div class="mt-1 text-slate-700">Kẻ tấn công được ghép offline từ phiên người khác; cơ chế kiểm tra chống phát lại mới ở mức thiết kế.</div>
  </div>

  <div v-click="2" class="rounded-lg border-l-4 border-amber-500 bg-amber-50/80 p-2.5 shadow-sm">
    <div class="font-bold text-amber-900 text-[14.5px]">MFA chưa phải hệ thống thật</div>
    <div class="mt-1 text-slate-700">Giả định lý tưởng: chủ tài khoản luôn vượt qua MFA thành công, kẻ lạ luôn xác thực thất bại.</div>
  </div>

  <div v-click="2" class="rounded-lg border-l-4 border-slate-500 bg-slate-50 p-2.5 shadow-sm">
    <div class="font-bold text-slate-800 text-[14.5px]">So sánh chưa hoàn toàn cân bằng</div>
    <div class="mt-1 text-slate-700">Các cấu hình hỏi MFA với tần suất khác nhau nên chưa so được ở cùng mức đánh đổi, kết luận mới dừng ở bước đầu.</div>
  </div>
</div>

<!-- Dải đỏ nhạt Chưa triển khai -->
<div v-click="3" class="mt-3 rounded border border-rose-300 bg-rose-100/70 p-2.5 text-[12.5px] text-rose-900 flex items-center gap-2">
  <span class="font-bold bg-rose-600 text-white px-2 py-0.5 rounded text-[11px] uppercase tracking-wide shrink-0">Chưa hiện thực:</span>
  <span>Hệ thống live end-to-end &bull; Chống phát lại trên mạng &bull; Cập nhật hồ sơ sau MFA (P2) &bull; Thuật toán One-Class SVM</span>
</div>

<!--
Mục tiêu: 0:45

Giới hạn lớn nhất là dữ liệu và MFA đều mô phỏng, kẻ tấn công ghép offline, và các cấu hình hỏi MFA với tần suất khác nhau nên kết luận mới là bước đầu. Live, chống phát lại, P2 và One-Class SVM chưa làm.
-->
