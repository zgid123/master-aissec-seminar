---
layout: shifting-intro
hideInToc: true
transition: slide-left
---

# Kết luận và hướng phát triển

<div class="mt-2 grid grid-cols-[1.1fr_1fr] gap-5 text-[14px] leading-snug items-start">
  <!-- Left column: Điều rút ra -->
  <div class="flex flex-col gap-2">
    <div class="font-bold text-slate-700 text-[13px] uppercase tracking-wider flex items-center gap-1.5">
      <div class="i-carbon-idea text-sky-600 text-lg"></div> Điều rút ra
    </div>
    <div class="rounded border-l-4 border-sky-500 bg-sky-50 p-2.5 shadow-sm">
      <b>1. Khoảng hở sau MFA là có thật;</b><br>
      <span class="text-slate-700">Nhịp gõ là tín hiệu bổ sung thụ động, không làm gián đoạn người dùng.</span>
    </div>
    <div v-click="1" class="rounded border-l-4 border-amber-500 bg-amber-50 p-2.5 shadow-sm">
      <b>2. Trong mô phỏng, cộng dồn tăng phát hiện</b><br>
      <span class="text-slate-700">Nhưng kèm nhiều lần hỏi MFA hơn: một đánh đổi tất yếu, chưa phải kết luận tối ưu.</span>
    </div>
    <div v-click="2" class="rounded border-l-4 border-emerald-500 bg-emerald-50 p-2.5 shadow-sm">
      <b>3. Đóng góp chính là quy trình đánh giá</b><br>
      <span class="text-slate-700">Kiểm lại được độc lập (TTD, MFA/giờ, đối chiếu), sẵn sàng chạy trên dữ liệu thật.</span>
    </div>
  </div>

  <!-- Right column: Bước tiếp theo -->
  <div v-click="3">
    <div class="font-bold text-slate-700 text-[13px] uppercase tracking-wider flex items-center gap-1.5">
      <div class="i-carbon-direction-straight-right text-emerald-600 text-lg"></div> Bước tiếp theo
    </div>

  <ol class="mt-2 list-decimal pl-4 space-y-2 text-slate-700">
    <li class="bg-slate-50 p-2 rounded border border-slate-200">
      <b>Thu dữ liệu thật:</b><br>
      20 người &times; 5 phiên (2 train, 2 validation, 1 test) bằng công cụ collector đã kiểm thử.
    </li>
    <li class="bg-slate-50 p-2 rounded border border-slate-200">
      <b>Gắn hệ thống live:</b><br>
      Ghép collector với bộ điều khiển phiên, bổ sung lớp truyền chống phát lại.
    </li>
    <li class="bg-slate-50 p-2 rounded border border-slate-200">
      <b>Triển khai P2:</b><br>
      Tự cập nhật hồ sơ sau MFA, thử nghiệm thêm đặc trưng và tinh chỉnh ngưỡng tối ưu.
    </li>
  </ol>
  </div>
</div>

<!--
Mục tiêu: 0:45

Tóm lại, nhịp gõ bổ sung cho MFA chứ không thay thế. Kết quả mô phỏng cho thấy cộng dồn tăng phát hiện nhưng kéo theo nhiều lần xác thực lại. Đóng góp chính là quy trình đánh giá kiểm lại được. Bước tiếp theo là thu dữ liệu thật của 20 người.
-->
